return {
    hotspot = {},
    game_width = 240,
    game_height = 135,
    scale = 6,

    key = {
        skip = ".",
        cutscene = "space",
        pause = "escape",
    },
    skip_with_left = false,
    skip_with_right = false,
    debug = false,

    flags = {
        
    },
}