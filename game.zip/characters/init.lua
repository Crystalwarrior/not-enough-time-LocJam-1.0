local global = require("global")
global.characters = {
  ines = require("characters.ines"),
  holeegram = require("characters.holeegram"),
  lee = require("characters.lee"),
  andrea = require("characters.andrea"),
  paolo = require("characters.paolo"),
  peppe = require("characters.peppe"),
  collector = require("characters.collector"),
  president_ines = require("characters.president_ines")
}
