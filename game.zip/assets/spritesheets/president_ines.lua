return {
  {
    {
      name = "talk1",
      x = 2,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk10",
      x = 2,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk11",
      x = 74,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk12",
      x = 74,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk2",
      x = 26,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk3",
      x = 50,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk4",
      x = 2,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk5",
      x = 2,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk6",
      x = 74,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk7",
      x = 98,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk8",
      x = 122,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    {
      name = "talk9",
      x = 146,
      y = 2,
      w = 22,
      h = 59,
      orig_w = 64,
      orig_h = 64,
      offset_x = 21,
      offset_y = 3
    },
    filename = "president_ines.png"
  }
}